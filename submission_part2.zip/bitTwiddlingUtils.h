#ifndef BITTWIDDLINGUTILS_H
#define BITTWIDDLINGUTILS_H

#include "stdio.h"
#include "stdlib.h"

void btuMultiDirectionBitShift(unsigned char * byte, int shift);
int btuPopCount(unsigned char byte);

#endif