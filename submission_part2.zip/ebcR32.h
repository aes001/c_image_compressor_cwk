#ifndef EBCR32_H
#define EBCR32_H

#include "ebUniversalUtils.h"
#include "ebcUtils.h"
#include <math.h>
#include "stdlib.h"
#include "blockUtils.h"
#include "ebcrUtils.h"
#define PARADIGM_COUNT 32

#endif
