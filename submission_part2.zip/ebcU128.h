#ifndef EBCU128_H
#define EBCU128_H

#include "ebcUtils.h"
#include "ebUniversalUtils.h"
#include "ebcrUtils.h"
#include "blockUtils.h"
#define PARADIGM_COUNT 128

#endif