#ifndef EBCU32_H
#define EBCU32_H

#include "ebcUtils.h"
#include "ebUniversalUtils.h"
#include "ebcrUtils.h"
#include "blockUtils.h"
#define PARADIGM_COUNT 32

#endif