#ifndef EBCR128_H
#define EBCR128_H

#include "ebcrUtils.h"
#include "ebUniversalUtils.h"
#include "ebcUtils.h"
#include "blockUtils.h"

#define PARADIGM_COUNT 128

#endif