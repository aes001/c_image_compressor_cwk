#ifndef ebBlock_h
#define ebBlock_h

#include "ebUniversalUtils.h"
#include "blockUtils.h"
#include "ebcUtils.h"
#include <math.h>

// function prototypes

#endif